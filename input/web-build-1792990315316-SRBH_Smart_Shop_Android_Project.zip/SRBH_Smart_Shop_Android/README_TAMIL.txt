SRBH SMART SHOP - ANDROID PROJECT (FIRST BUILD)

இந்த ZIP-ல் Android Studio project source உள்ளது. இது நேரடியாக APK அல்ல.

இப்போது உள்ளவை:
- தற்போதைய SRBH HTML app assets-ல் சேர்க்கப்பட்டுள்ளது.
- Android WebView மூலம் local HTML திறக்கும்.
- JavaScript மற்றும் localStorage enabled; சாதனத்தில் offline data சேமிப்பதற்கான அடிப்படை அமைப்பு.
- Camera permission கேட்கும்; ஆனால் தற்போதைய HTML barcode scanner WebView/file URL-ல் சரியாக இயங்குமா என்று device-ல் test செய்ய வேண்டும்.

இன்னும் செய்ய வேண்டியவை:
1. Android Studio-ல் project திறந்து Gradle sync/build செய்து APK உருவாக்க வேண்டும்.
2. Barcode scanning-ஐ Android native scanner-ஆக இணைத்து சோதிக்க வேண்டும்; permission மட்டும் இருப்பதால் scanner உறுதி கிடையாது.
3. Google Drive Backup/Restore இன்னும் இணைக்கப்படவில்லை. அதற்கு Google Cloud project, OAuth consent/configuration மற்றும் Drive API integration தேவை.
4. Offline storage data reset/uninstall ஆகும்போது இழக்கப்படலாம். Backup செய்து Restore சோதிக்காமல் முக்கியமான வணிகத் தரவை மட்டும் இதை நம்பி வைக்க வேண்டாம்.

APK உருவாக்க அடிப்படை:
- Android Studio-ஐ கணினியில் நிறுவவும்.
- File > Open மூலம் இந்த project folder-ஐத் திறக்கவும்.
- Gradle sync முடிந்ததும் Build > Build APK(s) தேர்வு செய்யவும்.
- Build செய்த பிறகு APK path பொதுவாக app/build/outputs/apk/debug/app-debug.apk.

குறிப்பு: இந்த project-ஐ source scaffold ஆக வழங்குகிறோம்; compiled/tested APK அல்ல.
