# SRB HN — Easy to Sell (Android starter project)

This is an Android Studio/Gradle project wrapper for the SRB HN web billing UI.

## Important honest limitations
- The bundled UI stores information locally in this app/WebView. It does **not** sync phone and PC.
- There is no production authentication or cloud database configured yet.
- UPI is not a verified payment gateway; the app may hand off UPI links only when configured.
- Barcode camera behavior depends on WebView/browser API support; hardware scanner or typed barcode is a fallback.
- This is a starter project and must be built and tested on Android Studio or the target CI before being treated as release-ready.

## Build
Recommended: Android Studio with JDK 17, Android SDK 34, Android Gradle Plugin 8.1.4 and Gradle 8.0.
1. Extract the ZIP.
2. Open the `SRB_HN_Android_Project` folder in Android Studio.
3. Let Gradle sync.
4. Build > Build APK(s).

For CI systems that expect a Gradle wrapper, generate one in Android Studio/terminal with `gradle wrapper --gradle-version 8.0`, then commit `gradlew`, `gradlew.bat`, and `gradle/wrapper/`.

## Web and PC use
The `index.html` is bundled as Android assets. For PC and cross-device sync, deploy the web app separately to HTTPS and configure a real shared cloud database/auth service. This starter does not configure that backend.
